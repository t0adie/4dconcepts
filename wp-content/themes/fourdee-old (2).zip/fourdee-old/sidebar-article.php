<?php if ( function_exists ( dynamic_sidebar(article) ) ) : ?>
<?php dynamic_sidebar (article); ?>

<?php endif; // end sidebar widget area ?>
