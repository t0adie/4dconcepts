<a class="article-link" href="<?php the_permalink(); ?>">
    <div class="text">
	<h1 class="head"><?php the_title(); ?></h1>
	<?php the_excerpt(); ?>
	<button class="btn cta">Read more</button>
    </div>
</a>
