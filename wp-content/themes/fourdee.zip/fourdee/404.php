<?php get_header(); ?>
<div id="contentWrap">
	<div id="content">
    	<h2>Sorry! The page you're looking for is not here.</h2>
    </div> <!-- end content -->
    <?php get_sidebar(); ?>
</div> <!-- end contentWrap -->
<?php get_footer(); ?>