// Javascript Document

jQuery(function ($){
	
var $spotlightArticle = $('ul#spotlight-articles li');
var $spotlightArticles = $('ul#spotlight-articles');

$spotlightArticle.each(function(index) {
	
	$spotlightArticle.css({'width': $(window).width() / 6});
	$spotlightArticles.css({'width': $spotlightArticle.width() * $spotlightArticle.size()});
    $(this).css({'left': index * $spotlightArticle.width()});
	
});

// SET THE NAVIGATION BUTTONS


function goLeft(){
	
	var $index = $('#spotlight-articles article.current').index();
	var $current = $('#spotlight-articles article.current');
	var $next = $current.next();
	
	if ($index - 1 === $current.size()){
		$next = $('#spotlight-articles article').first();
	}
	
	$next.addClass('current');
	$current.removeClass('current');
	
}

function goRight(){
	
	var $index = $('#spotlight-articles article.current').index();
	var $current = $('#spotlight-articles article.current');
	var $next = $current.next();
	
	$next.addClass('current');
	$current.removeClass('current');
	
}

$('#left-bracket').click(function(){
	
	goRight();
	
	var $index = $('#spotlight-articles article.current').index();
	$spotlightArticles.animate({'right': $index * $spotlightArticle.width()}, 1000);
	
});

$(' #right-bracket').click(function(){
	
	goLeft();
	
	var $index = $('#spotlight-articles article.current').index();
	$spotlightArticles.animate({'right': $index * $spotlightArticle.width()}, 1000);
	
});

});