<?php get_header(); ?>

<?php while ( have_posts() ) : the_post();?>

<section class="section-isotope" id="post-<?php the_ID(); ?>" <?php set_home_background(); ?> data-type="background" data-speed="-2"></section>
<div class="outerWrapper">
  <div class="wrapper">
    <div class="meta">
      <?php the_category() ?>
      <span id="author"> By:
      <?php the_author(); ?>
      </span> <span id="date">
      <?php the_date(); ?>
      </span>
      <h2>
        <?php the_title(); ?>
      </h2>
      <?php sharing_display() ?>
      <?php 
		  	  if ( function_exists( 'sharing_display' ) ) {
			  sharing_display( '', true );
			  }
			  
			  if ( class_exists( 'Jetpack_Likes' ) ) {
			  $custom_likes = new Jetpack_Likes;
			  echo $custom_likes->post_likes( '' );
			  }
		  ?>
    </div>
    <?php 
	
	get_template_part( 'content', get_post_format() );
	
	if ( comments_open() ) {
		comments_template();
	} ?>
  </div>
</div>
<?php endwhile; ?>
<?php get_footer(); ?>