<?php get_header(); ?>
<div class="wrapper">
	
    	<h2>Sorry! The page you're looking for is not here.</h2>
    
</div> <!-- end .wrapper -->
<?php get_footer(); ?>