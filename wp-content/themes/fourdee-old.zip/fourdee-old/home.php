<?php get_header(); ?>

<section class="isotopes">
  <?php query_posts( 'pagename=approach' );
  	  if ( have_posts ) : 
		  while ( have_posts() ) : the_post(); ?>
  <dl class="isotope">
    <dt <?php set_home_background() ?>></dt>
    <dd>
      <div class="padding" id="left">
        <hgroup>
          <h1> <?php echo get_post_meta($post->ID, 'headline', true); ?> </h1>
          <span><?php echo get_post_meta($post->ID, 'caption', true); ?></span> </hgroup>
        <div class="more"><a href="<?php the_permalink() ?>">Learn More</a></div>
      </div>
    </dd>
  </dl>
  <?php endwhile; ?>
  <div class="marquee-nav"></div>
  <?php endif; ?>
</section>
<!-- .banner -->
<div class="outerWrapper">
  <div class="wrapper">
    <div id="center" class="padding">
    <hgroup>
      <h1>Not just another design amd web company.</h1>
      <span>We merit design and function by creating unique user experiences.</span> </hgroup>
    <div class="more"><a href="<?php echo esc_url( get_permalink( get_page_by_title( 'Services' ) ) ); ?>">What We Do</a></div>
    </div>
  </div>
  <!-- .wrapper --> 
</div>
<!-- .outterWrapper -->
<?php get_footer(); ?>
