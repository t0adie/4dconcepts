<?php get_header(); ?>

<div class="wrapper">
  <article <?php post_class() ?> id="post-<?php the_ID(); ?>">
    <section class="sidebar">
      <?php dynamic_sidebar( 'sidebar-article' ); ?>
    </section>
  </article>
</div>
<?php get_footer(); ?>
