// JavaScript Document

$(document).ready(function() {
    
var $window = $(window);
var $dl = $('dl');
var $dd = $('dd');

});