// JavaScript Document

jQuery(document).ready(function($){
	
	$width = $('body').width();
	$height = $(window).height() - ($(window).height() / 4);
	$section = $('section.isotopes dl, section.isotopes dl dt');
	$caption = $('section.isotopes dl dd');
	$header = $('header');
	$menu = $('menu.popOut');
	$submenu = $('ul.sub-menu');	
	
	$menu.width($width).height($(window).height());
	$submenu.width($('menu.popOut').width() + 50);

	var $window = $('body');
    var $dl = $('dl');
    var $dd = $('dd');
	
    var $menuItem = $(".popOut li.menu-item");

    function niceFade() {
        $menuItem.each(function (index) {
            $(this).delay(index * 20).fadeIn({
                duration: 300,
                queue: false
            });
            $(this).delay(index * 20).animate({
                "top": 0
            }, 300);
        });
    }

    function resetMenu() {
		
		var $menuItem = $($(".popOut li.menu-item").get().reverse());
		
        $menuItem.each(function (index) {
            $(this).delay(index * 20).fadeOut({
                duration: 300,
                queue: false
            });
            $(this).delay(index * (-20)).animate({
                "top": 200
            }, 300);
        });
    }

    var navOut = false;

    $('#toggle-switch').on('click', function() {
        $('menu.popOut').fadeIn({duration: 300, queue: false});
		niceFade();
		return false;
    });

    $('body').on('click', function (e) {
        $('menu.popOut').fadeOut({duration: 300, queue: false});
		resetMenu();
		return true;
    });
	
});

