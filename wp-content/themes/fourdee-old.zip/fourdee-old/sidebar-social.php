<?php if ( function_exists ( dynamic_sidebar(social) ) ) : ?>
<?php dynamic_sidebar (social); ?>
  <ul>
    <li id="facebook"></li>
    <li id="twitter"></li>
    <li id="google"></li>
    <li id="pin"></li>
  </ul>
<?php endif; // end sidebar widget area ?>
