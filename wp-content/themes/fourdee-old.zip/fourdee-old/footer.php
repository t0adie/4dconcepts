
<footer>
  <div id="outerWrapper">
    <div id="social-footer">
      <?php dynamic_sidebar('users') ?>
      <?php dynamic_sidebar('subscribe') ?>
      <?php dynamic_sidebar('social') ?>
    </div>
    <!-- end #social-footer -->
    <nav class="footerMenu">
      <div class="menu">Copyright &copy; <?php echo date("Y"); ?> Fourdee. All rights Reserved</div>
      <?php wp_nav_menu( array( 'theme_location' => 'footer', 'container_class' => 'menu-header', 'menu_class' => 'menu' ) ); ?>
      <div class="menu"><span class="social" id="twitter"></span><span class="social" id="facebook"></span><span class="social" id="blog"></span></div>
    </nav>
  </div>
</footer>
<!-- end #outer-wrapper -->
<?php wp_footer(); ?>
</body></html>