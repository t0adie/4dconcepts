<?php the_content(); ?>
<?php wp_link_pages(); ?>