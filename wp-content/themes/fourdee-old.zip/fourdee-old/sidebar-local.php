<?php if ( function_exists ( dynamic_sidebar(local) ) ) : ?>
<?php dynamic_sidebar (local); ?>
<?php endif; // end sidebar widget area ?>
